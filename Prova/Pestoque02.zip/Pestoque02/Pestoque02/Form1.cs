﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxEstoque.Items.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] estoque = new int[4, 4];

            int totalGeral = 0;

            string auxiliar;

            for(int i = 0; i < 4; i++)
            {
                int qtdProduto = 0; 
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a quantidade de produto: {i + 1} que entrou na semana: {j + 1} ", "Entrada de produtos");

                    if(!int.TryParse(auxiliar, out estoque[i,j]) || estoque[i,j] < 0)
                    {
                        MessageBox.Show("Quantidade inválida");
                        j--;
                    }
                    else
                    {
                        qtdProduto += estoque[i,j];
                lstbxEstoque.Items.Add(($"Total Entradas do Produto: {i + 1} Semana: {j + 1} - {estoque[i,j]}"));
                    }
                }
                totalGeral += qtdProduto;
                lstbxEstoque.Items.Add($">> Total Entradas do Produto: {i+1}              {qtdProduto}");
                lstbxEstoque.Items.Add($"--------------------------------------------------------------------");
            }

            lstbxEstoque.Items.Add($">> Total Geral Entradas                            {totalGeral}");
            

        }
    }
}
