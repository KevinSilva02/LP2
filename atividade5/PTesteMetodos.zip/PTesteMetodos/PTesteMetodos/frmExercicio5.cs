﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteia_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if(!int.TryParse(txtNumero1.Text, out numero1) ||
               !int.TryParse(txtNumero2.Text, out numero2) ||
               (numero2 <= numero1))
            {
                MessageBox.Show("Números inválidos");
                txtNumero1.Focus();
            }
            else
            {
                Random objR = new Random();
                int aleatorio = objR.Next(numero1, numero2);
                MessageBox.Show("Número aleatorio: " + aleatorio);
            }
        }
    }
}
