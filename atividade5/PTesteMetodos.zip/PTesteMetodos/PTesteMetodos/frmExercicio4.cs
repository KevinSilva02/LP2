﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnConta_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int contNum = 0;

            while (cont < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[cont]))
                {
                    contNum++;
                }

                cont++;
            }

            MessageBox.Show("Quantidade de caracteres numericos: " + contNum.ToString());
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for(int i = 0;i<rchtxtFrase.Text.Length;i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            MessageBox.Show("Posição do 1º espaço em branco: " + posicao.ToString());
        }

        private void btnCaracterAlfabetico_Click(object sender, EventArgs e)
        {
            string auxiliar = rchtxtFrase.Text;
            char[] arr = auxiliar.ToCharArray();


            int cont = 0;
            foreach(char alfabetico in arr) 
            {
                if (char.IsLetter(alfabetico))
                {
                    cont++;
                }
            }

            MessageBox.Show("Quantidade de caracteres alfabeticos: " + cont.ToString());
        }
    }
}
