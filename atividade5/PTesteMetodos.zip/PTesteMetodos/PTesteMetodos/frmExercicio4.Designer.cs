﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnConta = new System.Windows.Forms.Button();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnCaracterAlfabetico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(68, 41);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(701, 96);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnConta
            // 
            this.btnConta.Location = new System.Drawing.Point(68, 267);
            this.btnConta.Name = "btnConta";
            this.btnConta.Size = new System.Drawing.Size(122, 81);
            this.btnConta.TabIndex = 1;
            this.btnConta.Text = "Contar caracters";
            this.btnConta.UseVisualStyleBackColor = true;
            this.btnConta.Click += new System.EventHandler(this.btnConta_Click);
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(368, 267);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(122, 81);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "1° caracter braco (posição)";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnCaracterAlfabetico
            // 
            this.btnCaracterAlfabetico.Location = new System.Drawing.Point(647, 267);
            this.btnCaracterAlfabetico.Name = "btnCaracterAlfabetico";
            this.btnCaracterAlfabetico.Size = new System.Drawing.Size(122, 81);
            this.btnCaracterAlfabetico.TabIndex = 3;
            this.btnCaracterAlfabetico.Text = "Contar caracters alfabetico";
            this.btnCaracterAlfabetico.UseVisualStyleBackColor = true;
            this.btnCaracterAlfabetico.Click += new System.EventHandler(this.btnCaracterAlfabetico_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracterAlfabetico);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.btnConta);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnConta;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnCaracterAlfabetico;
    }
}