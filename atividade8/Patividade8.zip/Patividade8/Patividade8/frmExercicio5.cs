﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Patividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string saida = "";
            string[,] provas = new string[3,10];

            string[] gabarito = {"A","A","A","B","A","A","A","A","A","A" };

            for(int i = 0; i < 3; i++)
            {
                for(int c = 0; c < 10; c++)
                {
                    provas[i, c] = Interaction.InputBox($"Aluno: {i+1} Informe a resposta da questão: {c+1} ", "Respostas").ToUpper();
                }
            }

            for(int i = 0; i < 3; i++)
            {
                for(int c = 0; c < 10; c++)
                {
                    if (provas[i,c] == gabarito[c])
                    {
                        lstbxResultado.Items.Add($"O aluno: {i + 1} acertou questão: {c + 1} era {gabarito[c]} escolheu {provas[i, c]}");
                    }
                    else
                    {
                        lstbxResultado.Items.Add($"O aluno: {i + 1} errou questão: {c + 1} era {gabarito[c]} escolheu {provas[i, c]}");
                    }
                }
            }




        }
    }
}
