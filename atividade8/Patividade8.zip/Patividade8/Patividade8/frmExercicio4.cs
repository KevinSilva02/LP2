﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string auxiliar = "";
            int[] qtdDeCaracters = new int[10];
            string saida = "";

            for(int i = 0; i < 2; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° nome: ", "entrada de nome");

                if(auxiliar.Replace(" ", "").Length==0)
                {
                    MessageBox.Show("Nome Invalido");
                    i--;
                }else
                {
                    nomes[i] = auxiliar;
                    auxiliar = auxiliar.Replace(" ", "");
                    qtdDeCaracters[i] = auxiliar.Length;
                }
            }

            for(int i = 0;i < 2; i++)
            {
                lstbxNomes.Items.Add($"o nome: {nomes[i]} tem {qtdDeCaracters[i]} caracters \n");
            }
            
        }
    }
}
