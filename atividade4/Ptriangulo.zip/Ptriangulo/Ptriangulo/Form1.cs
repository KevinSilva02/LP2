﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out valorB) || valorB == 0 )
            {
                MessageBox.Show("Valor Inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtValorC.Text, out valorC) || valorC == 0 )
            {
                MessageBox.Show("Valor inválido");
                txtValorC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtValorA.Text) || string.IsNullOrEmpty(txtValorB.Text) || string.IsNullOrEmpty(txtValorC.Text) )
            {
                MessageBox.Show("Preencha todos os campos");
            }
            else if((Math.Abs(valorB - valorC) < valorA && valorA < valorB + valorC) || 
               (Math.Abs(valorA - valorC) < valorB && valorB < valorA + valorC) ||
               (Math.Abs(valorA - valorB) < valorC && valorC < valorA + valorB))
            {   
                if(valorA == valorB && valorA == valorC)
                {
                    MessageBox.Show("Forma um triangulo equilátero");
                }
                else if(valorA == valorB || valorA == valorC || valorB == valorC)
                {
                    MessageBox.Show("Forma um triangulo isóceles");
                } else
                {
                    MessageBox.Show("Forma um triangulo escaleno");
                }
            }else
            {
                MessageBox.Show("Não é um triangulo");
            }
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtValorA.Text, out valorA) || valorA == 0 )
            {
                MessageBox.Show("Numero invalido");
                txtValorA.Focus();
            }
        }
    }
}
