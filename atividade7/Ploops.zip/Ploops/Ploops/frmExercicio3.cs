﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text.ToUpper();
            frase = frase.Replace(" ", "");
            char[] arrayFrase = frase.ToCharArray();

            Array.Reverse(arrayFrase);

            string fraseInvertida = "";

            foreach (char c in arrayFrase)
            {
                fraseInvertida += c.ToString();
            }

            if(String.Compare(frase, fraseInvertida) == 0)
            {
                MessageBox.Show($"Frase: {frase}, frase Invertida: {fraseInvertida},é palindromo ");
            }
            else
            {
                MessageBox.Show($"Frase: {frase}, frase Invertida: {fraseInvertida}, NÃO é palindromo ");
            }
            

        }
    }
}
