﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int cont = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if(Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    cont++;
                }
            }

            MessageBox.Show($"A quantidade de espaços em branco são: {cont}");
        }

        private void btnContR_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int indice = 0;
            while(indice < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[indice] == 'R' || rchtxtFrase.Text[indice] == 'r')
                {
                    cont++;
                }

                indice++;
            }

            MessageBox.Show($"A quantidade de letras 'R' é: {cont}");
        }

        private void btnContPar_Click(object sender, EventArgs e)
        {
            int indice = 0;
            int cont = 0;
            do
            {
                if (rchtxtFrase.Text[indice] == rchtxtFrase.Text[indice + 1])
                {
                    cont++;
                }

                indice++;
            } while (indice < rchtxtFrase.Text.Length - 1);

            MessageBox.Show($"A quantidade de pares de letras é: {cont}");
        }
    }
}
